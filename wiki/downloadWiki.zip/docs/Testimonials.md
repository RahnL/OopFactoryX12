# Testimonials
If you have a success story to share about your usage of the X12 Parser, please add a comment to this page and answer some of the folloing questions:
* How have you been able to use the X12 Parser?
* Has it affected your cost of implementation?
* Has it affected your time to market?